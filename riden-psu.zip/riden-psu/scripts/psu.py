#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RIDEN (睿登) RD60xx 系列直流电源 —— 串口控制工具（Modbus RTU）

本工具按「安全优先」设计，所有会改变电源状态的命令都带护栏：

  1. 改电压/电流时必须用 --confirm 再写一遍目标值，两次不一致直接拒绝执行。
     这是防手抖的核心：set-voltage 48 --confirm 5 会被拦下。
  2. 改设定值前要求输出已关闭（除非显式 --allow-live），
     避免带着负载把电压从 5V 跳到 48V。
  3. 每次写入后立刻回读寄存器比对，不一致就报错退出（退出码 3），
     绝不假设"写进去了"。
  4. 目标值按型号硬上限限制（RD6012P: 60V / 12A），超限直接拒绝。
  5. 目标电压高于当前 OVP 阈值时拒绝（否则一开输出就保护）。
  6. 打开输出必须带 --expect-volts，强制先确认当前设定值再上电。
  7. 不提供寄存器裸写入口，校准寄存器（55-64）、bootloader（256）碰不到。

用法示例：
  python psu.py status
  python psu.py output off
  python psu.py set-voltage 5.000 --confirm 5.000
  python psu.py output on --expect-volts 5.000
  python psu.py monitor -n 10 -i 0.5
  python psu.py read --raw

退出码：0 成功 / 2 被安全规则拒绝 / 3 设备通信或回读校验失败 / 4 串口打不开
"""

import argparse
import json
import struct
import sys
import time

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    sys.stderr.write("缺少 pyserial，请先执行: pip install pyserial\n")
    sys.exit(4)

DEFAULT_BAUD = 115200
DEFAULT_ADDR = 1

# ---------------------------------------------------------------- 寄存器定义
REG_ID = 0
REG_SN_HI = 1
REG_SN_LO = 2
REG_FW = 3
REG_TEMP_SIGN = 4
REG_TEMP_C = 5
REG_V_SET = 8
REG_I_SET = 9
REG_V_OUT = 10
REG_I_OUT = 11
REG_V_IN = 14
REG_LOCK = 15
REG_PROTECT = 16
REG_CVCC = 17
REG_OUTPUT = 18
REG_PRESET = 19
REG_I_RANGE = 20
REG_BOOT_POWER = 68
REG_M0_V = 80
REG_M0_I = 81
REG_M0_OVP = 82
REG_M0_OCP = 83

# 校准区实测延伸到 64。48-53 时钟与 66/67/70/71 设置项设备允许写，本脚本不提供对应命令。
FORBIDDEN_WRITE = set(range(0, 8)) | set(range(48, 54)) | set(range(55, 65)) | {66, 67, 70, 71, 256}

PROTECT_NAMES = {0: "正常", 1: "过压保护 OVP", 2: "过流保护 OCP"}

# 型号表: id -> (名称, 最高电压, 最大电流, 是否高精度, 是否双量程)
MODELS = {
    60061: ("RD6006", 60.0, 6.0, False, False),
    60062: ("RD6006", 60.0, 6.0, False, False),
    60065: ("RD6006P", 60.0, 6.0, True, False),
    60121: ("RD6012", 60.0, 12.0, False, False),
    60125: ("RD6012P", 60.0, 12.0, True, True),
    60181: ("RD6018", 60.0, 18.0, False, False),
    60241: ("RD6024", 60.0, 24.0, False, False),
    60301: ("RD6030", 60.0, 30.0, False, False),
}


class DeviceError(RuntimeError):
    pass


class SafetyError(RuntimeError):
    pass


def crc16(data: bytes) -> bytes:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return struct.pack("<H", crc)


class PSU:
    def __init__(self, port="auto", baud=DEFAULT_BAUD, addr=DEFAULT_ADDR, timeout=0.6, retries=4, quiet=False):
        self.addr = addr
        self.timeout = timeout
        self.retries = retries
        self.quiet = quiet
        self.ser = None

        if port in (None, "", "auto"):
            port = self.autodetect()
        self.port = port
        self.baud = baud
        try:
            self.ser = serial.Serial(port, baud, timeout=timeout)
            self.ser.reset_input_buffer()
            self.ser.reset_output_buffer()
        except serial.SerialException as exc:
            raise DeviceError(
                f"打不开串口 {port}: {exc}\n"
                "常见原因：串口被瑞登官方的上位机软件/串口助手占用，或 COM 号不对。\n"
                "先关掉占用程序，或用 `python psu.py ports` 重新确认端口号。"
            ) from exc
        self.model_id = None
        self.model_name = ""
        self.vmax = 60.0
        self.imax = 12.0
        self.precision = True
        self.dual_range = True
        self._identify()

    # ------------------------------------------------------------ 通信底层
    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _send(self, payload: bytes):
        self.ser.reset_input_buffer()
        self.ser.write(payload + crc16(payload))
        self.ser.flush()
        time.sleep(0.06)

    def _read_regs(self, start, count):
        payload = struct.pack(">BBHH", self.addr, 3, start, count)
        last = "无响应"
        for _ in range(self.retries):
            try:
                self._send(payload)
            except serial.SerialException as exc:
                last = str(exc)
                continue
            header = self.ser.read(3)
            if len(header) < 3:
                last = "响应超时"
                continue
            if header[0] != self.addr:
                last = f"从站地址不匹配: 0x{header[0]:02X}"
                continue
            if header[1] == 0x83:
                body = header + self.ser.read(3)
                code = body[3] if len(body) > 3 else 0
                raise DeviceError(f"设备返回 Modbus 异常码 0x{code:02X}（寄存器 {start}）")
            if header[1] != 3:
                last = f"功能码异常: 0x{header[1]:02X}"
                continue
            byte_count = header[2]
            rest = self.ser.read(byte_count + 2)
            if len(rest) < byte_count + 2:
                last = "数据帧不完整"
                continue
            frame = header + rest
            if crc16(frame[:-2]) != frame[-2:]:
                last = "CRC 校验失败"
                continue
            return [struct.unpack(">H", frame[3 + i * 2:5 + i * 2])[0] for i in range(byte_count // 2)]
        raise DeviceError(f"读取寄存器 {start} 失败（{last}）。检查电源是否上电、串口是否被占用。")

    def _write_reg(self, reg, value):
        if reg in FORBIDDEN_WRITE:
            raise SafetyError(f"寄存器 {reg} 属于校准/配置/引导区，禁止写入")
        if not 0 <= value <= 0xFFFF:
            raise SafetyError(f"写入值 {value} 超出 16 位范围")
        payload = struct.pack(">BBHH", self.addr, 6, reg, value)
        expected = payload + crc16(payload)
        last = "无回显"
        for _ in range(self.retries):
            try:
                self._send(payload)
            except serial.SerialException as exc:
                last = str(exc)
                continue
            resp = self.ser.read(8)
            if resp == expected:
                return True
            if len(resp) >= 2 and resp[1] == 0x86:
                raise DeviceError(f"设备拒绝写入寄存器 {reg}（值 {value}）")
            last = f"回显异常: {resp.hex(' ') if resp else '空'}"
        raise DeviceError(f"写寄存器 {reg}={value} 失败（{last}）")

    def _write_verify(self, reg, value, label):
        """写入并回读校验，不一致自动重试，最终不一致则报错。"""
        for attempt in range(1, 3):
            self._write_reg(reg, value)
            time.sleep(0.08)
            got = self._read_regs(reg, 1)[0]
            if got == value:
                return True
            if not self.quiet:
                sys.stderr.write(f"  第 {attempt} 次回读不一致：期望 {value} 实得 {got}，重试…\n")
            time.sleep(0.15)
        raise DeviceError(f"{label} 写入后回读校验失败：期望 {value}，实得 {got}。设备状态可能未更新，请用 status 复查。")

    # ------------------------------------------------------------ 型号识别
    def _identify(self):
        self.model_id = self._read_regs(REG_ID, 1)[0]
        info = MODELS.get(self.model_id)
        if info is None:
            digits = str(self.model_id)
            v = int(digits[:2]) if len(digits) >= 4 else 60
            i = int(digits[2:4]) if len(digits) >= 4 else 12
            info = (f"RD{self.model_id}", float(v), float(i), digits.endswith("5"), digits.endswith("25"))
        self.model_name, self.vmax, self.imax, self.precision, self.dual_range = info

    # ------------------------------------------------------------ 单位换算
    @property
    def v_unit(self):
        return 0.001 if self.precision else 0.01

    @property
    def i_unit(self):
        if self.dual_range:
            return 0.001 if self.read_range() == 1 else 0.0001
        return 0.001

    @property
    def v_dec(self):
        return 3 if self.precision else 2

    @property
    def i_dec(self):
        return 4 if self.i_unit == 0.0001 else 3

    def read_range(self):
        return self._read_regs(REG_I_RANGE, 1)[0]

    def read_output(self):
        return self._read_regs(REG_OUTPUT, 1)[0]

    # ------------------------------------------------------------ 状态
    def status(self):
        regs = self._read_regs(0, 21)
        m0 = self._read_regs(REG_M0_V, 4)
        i_unit = 0.001 if (self.dual_range and regs[REG_I_RANGE] == 1) else (0.0001 if self.dual_range else 0.001)
        v_unit = self.v_unit
        temp = regs[REG_TEMP_C] * (-1 if regs[REG_TEMP_SIGN] else 1)
        v_out = regs[REG_V_OUT] * v_unit
        i_out = regs[REG_I_OUT] * i_unit
        return {
            "port": self.port,
            "model_id": regs[REG_ID],
            "model": self.model_name,
            "serial": (regs[REG_SN_HI] << 16) | regs[REG_SN_LO],
            "firmware": round(regs[REG_FW] / 100, 2),
            "temp_c": temp,
            "v_set": round(regs[REG_V_SET] * v_unit, 6),
            "i_set": round(regs[REG_I_SET] * i_unit, 6),
            "v_out": round(v_out, 6),
            "i_out": round(i_out, 6),
            "power": round(v_out * i_out, 3),
            "v_in": round(regs[REG_V_IN] / 100, 2),
            "keypad_lock": bool(regs[REG_LOCK]),
            "protect": regs[REG_PROTECT],
            "mode": "CC" if regs[REG_CVCC] else "CV",
            "output": bool(regs[REG_OUTPUT]),
            "preset": regs[REG_PRESET],
            "i_range": regs[REG_I_RANGE],
            "ovp": round(m0[2] * v_unit, 6),
            "ocp": round(m0[3] * i_unit, 6),
            "_raw": {"v_set": regs[REG_V_SET], "i_set": regs[REG_I_SET], "range": regs[REG_I_RANGE]},
        }

    # ------------------------------------------------------------ 串口自动搜索
    @staticmethod
    def _probe(dev, addr=DEFAULT_ADDR, attempts=3):
        """探测单个端口，返回型号 ID 或 None。

        串口偶发丢帧是常态：本机实测出现过约 1 秒的连续失败窗口，
        同一端口稍后即恢复。所以绝不能凭一次无应答就判定"设备不在"。
        """
        try:
            ser = serial.Serial(dev, DEFAULT_BAUD, timeout=0.35)
        except serial.SerialException:
            return None
        try:
            payload = struct.pack(">BBHH", addr, 3, REG_ID, 1)
            frame = payload + crc16(payload)
            for _ in range(attempts):
                ser.reset_input_buffer()
                ser.write(frame)
                ser.flush()
                time.sleep(0.1)
                resp = ser.read(7)
                if (len(resp) >= 7 and resp[0] == addr and resp[1] == 3
                        and crc16(resp[:-2]) == resp[-2:]):
                    return struct.unpack(">H", resp[3:5])[0]
                time.sleep(0.08)
        except serial.SerialException:
            return None
        finally:
            ser.close()
        return None

    @staticmethod
    def autodetect(passes=2):
        entries = [p for p in serial.tools.list_ports.comports()
                   if p.device.upper().startswith("COM") or "tty" in p.device]
        if not entries:
            raise DeviceError("没有找到任何串口设备。检查 USB 线是否插好。")
        # 真实 USB 转串口设备优先试，虚拟串口（如 ELTIMA 端口对）放后面，
        # 避免每次都在不会应答的端口上白等到超时。
        entries.sort(key=lambda p: 0 if "USB VID" in (p.hwid or "") else 1)
        candidates = [p.device for p in entries]

        found = None
        for attempt in range(passes):
            for dev in candidates:
                mid = PSU._probe(dev, attempts=3 if attempt else 2)
                if mid is not None:
                    found = (dev, mid)
                    break          # 命中即停，不再去试后面的虚拟串口
            if found:
                break
            if attempt < passes - 1:
                time.sleep(0.3)
        if not found:
            raise DeviceError(
                "在 %s 上都没有找到电源（已重复探测 %d 轮，仍无应答）。\n"
                "请确认：电源已上电且未处于待机（屏幕亮着）、USB 线已连接、"
                "瑞登上位机软件未占用串口。" % (", ".join(candidates), passes)
            )
        return found[0]


# ---------------------------------------------------------------- 输出格式
def print_status(st, psu):
    def line(label, value):
        print(f"  {label:<10}{value}")

    print("=" * 58)
    print(f"  {st['model']}  (ID {st['model_id']})   FW {st['firmware']}   SN {st['serial']}")
    print(f"  串口 {st['port']} @ {psu.baud}   从站地址 {psu.addr}")
    print("=" * 58)
    rng = ""
    if psu.dual_range:
        rng = "  (6A 档)" if st["i_range"] == 0 else "  (12A 档)"
    line("输出使能", ("● 开  OUTPUT ON" if st["output"] else "○ 关  OUTPUT OFF") + rng)
    line("设定电压", f"{st['v_set']:.{psu.v_dec}f} V")
    line("设定电流", f"{st['i_set']:.{psu.i_dec}f} A")
    line("实测电压", f"{st['v_out']:.{psu.v_dec}f} V")
    line("实测电流", f"{st['i_out']:.{psu.i_dec}f} A")
    line("输出功率", f"{st['power']:.3f} W   (P = V×I)")
    line("工作模式", st["mode"])
    line("输入电压", f"{st['v_in']:.2f} V")
    line("内部温度", f"{st['temp_c']} °C")
    line("保护状态", PROTECT_NAMES.get(st["protect"], f"未知({st['protect']})"))
    line("OVP / OCP", f"{st['ovp']:.{psu.v_dec}f} V / {st['ocp']:.{psu.i_dec}f} A")
    line("按键锁", "锁定" if st["keypad_lock"] else "解锁")
    print("=" * 58)


def human(st, psu):
    return (
        f"{st['model']} @{st['port']} 输出={'开' if st['output'] else '关'} "
        f"设定={st['v_set']:.{psu.v_dec}f}V/{st['i_set']:.{psu.i_dec}f}A "
        f"实测={st['v_out']:.{psu.v_dec}f}V/{st['i_out']:.{psu.i_dec}f}A "
        f"{st['mode']} {st['power']:.2f}W"
    )


# ---------------------------------------------------------------- 命令实现
def cmd_ports(args, psu=None):
    ports = list(serial.tools.list_ports.comports())
    if not ports:
        print("没有找到串口设备")
        return 0
    print(f"{'端口':<8}{'描述'}")
    print("-" * 60)
    for p in ports:
        print(f"{p.device:<8}{p.description}")
    return 0


def cmd_status(args, psu):
    st = psu.status()
    if args.json:
        print(json.dumps({k: v for k, v in st.items() if not k.startswith("_")}, ensure_ascii=False, indent=2))
    else:
        print_status(st, psu)
        if st["protect"] != 0:
            print(f"  ⚠ 保护已触发：{PROTECT_NAMES.get(st['protect'])}，需在面板上清除后才能正常输出。")
    return 0


def cmd_output(args, psu):
    st = psu.status()
    if args.state == "off":
        if not st["output"]:
            print("输出本来就是关闭状态，无需操作。")
            print(human(st, psu))
            return 0
        psu._write_verify(REG_OUTPUT, 0, "关闭输出")
        time.sleep(0.3)
        st2 = psu.status()
        if st2["output"]:
            raise DeviceError("已发送关闭命令，但回读显示输出仍为开启状态，请立即在面板上手动关闭！")
        print("✓ 输出已关闭")
        print(human(st2, psu))
        if st2["v_out"] > 0.05:
            print(f"  （实测电压 {st2['v_out']:.{psu.v_dec}f} V 是输出电容在放电，会逐渐归零）")
        return 0

    # ---- 打开输出：必须先确认设定值 ----
    if st["output"]:
        print("输出已经是开启状态，无需操作。")
        print(human(st, psu))
        return 0

    v_set = st["v_set"]
    if args.expect_volts is None:
        if not args.force:
            raise SafetyError(
                "打开输出前必须确认当前设定电压。\n"
                f"当前设定：{v_set:.{psu.v_dec}f} V / {st['i_set']:.{psu.i_dec}f} A\n"
                "请用 --expect-volts <你预期的电压> 再次执行；确认无误后才会真正上电。\n"
                "例：python psu.py output on --expect-volts %.3f" % v_set
            )
    else:
        if abs(args.expect_volts - v_set) > (psu.v_unit / 2):
            raise SafetyError(
                f"拒绝上电：你预期的电压是 {args.expect_volts:.3f} V，"
                f"但电源当前设定是 {v_set:.{psu.v_dec}f} V。\n"
                "请先用 status 核对，或先 set-voltage 改成目标值（务必确认后再改）。"
            )
    if st["protect"] != 0:
        raise SafetyError(f"拒绝上电：保护已触发（{PROTECT_NAMES.get(st['protect'])}），请先在面板上排查并清除。")

    psu._write_verify(REG_OUTPUT, 1, "打开输出")
    time.sleep(0.5)
    st2 = psu.status()
    if not st2["output"]:
        raise DeviceError("已发送开启命令，但回读显示输出仍为关闭，请检查设备。")
    print(f"✓ 输出已开启 —— 设定 {st2['v_set']:.{psu.v_dec}f} V / 限流 {st2['i_set']:.{psu.i_dec}f} A")
    print(human(st2, psu))
    return 0


def _guard_output_off(psu, args, action):
    if psu.read_output() and not args.allow_live:
        raise SafetyError(
            f"拒绝{action}：输出正在开启状态。\n"
            "带载时改动设定值可能损坏负载。请先执行 `output off`，改完再 `output on`。\n"
            "（确实需要在带载状态改动时，加 --allow-live，风险自负）"
        )


def _check_confirm(target, confirm, unit, label):
    raw_target = int(round(target / unit))
    raw_confirm = int(round(confirm / unit))
    if raw_target != raw_confirm:
        raise SafetyError(
            f"两次输入不一致，已拒绝执行：\n"
            f"  目标 {label} = {target}\n"
            f"  确认 {label} = {confirm}\n"
            "这是防止误设的关键一步。请重新核对目标值后再执行。"
        )
    return raw_target


def cmd_set_voltage(args, psu):
    st = psu.status()
    if args.volts < 0:
        raise SafetyError("电压不能为负")
    if args.volts > psu.vmax:
        raise SafetyError(f"{psu.model_name} 最高输出 {psu.vmax} V，{args.volts} V 超限，拒绝执行")
    opv = st["ovp"]
    if args.volts > opv and not args.allow_over_ovp:
        raise SafetyError(
            f"目标 {args.volts:.{psu.v_dec}f} V 高于当前 OVP 阈值 {opv:.{psu.v_dec}f} V，"
            "开输出后会立即触发过压保护。\n请先调高 OVP，或确认后加 --allow-over-ovp。"
        )
    raw = _check_confirm(args.volts, args.confirm, psu.v_unit, "电压")
    _guard_output_off(psu, args, "修改电压")

    print(f"目标电压 {args.volts:.{psu.v_dec}f} V  →  寄存器 {REG_V_SET} = {raw}"
          f"    (当前 {st['v_set']:.{psu.v_dec}f} V)")
    if args.dry_run:
        print("[dry-run] 未实际写入")
        return 0
    psu._write_verify(REG_V_SET, raw, "电压")

    time.sleep(0.1)
    st2 = psu.status()
    ok = abs(st2["v_set"] - args.volts) <= psu.v_unit / 2
    print(f"回读电压 {st2['v_set']:.{psu.v_dec}f} V   {'✓ 与目标一致' if ok else '✗ 与目标不符'}")
    if not ok:
        raise DeviceError(f"回读 {st2['v_set']} V 与目标 {args.volts} V 不一致")
    if st2["output"]:
        print(f"注意：输出处于开启状态，实测电压 {st2['v_out']:.{psu.v_dec}f} V")
    return 0


def cmd_set_current(args, psu):
    st = psu.status()
    if args.amps < 0.0001:
        raise SafetyError("电流设定必须大于 0，否则带载时输出会被限制为 0")
    range_max = (12.0 if st["i_range"] == 1 else 6.0) if psu.dual_range else psu.imax
    if args.amps > range_max:
        raise SafetyError(
            f"当前是 {'12A' if st['i_range'] else '6A'} 档，最大 {range_max} A，{args.amps} A 超限。\n"
            "需要更大电流请先切换到 12A 档：python psu.py set-range 12a --confirm 12a"
        )
    raw = _check_confirm(args.amps, args.confirm, psu.i_unit, "电流")
    _guard_output_off(psu, args, "修改电流")

    print(f"目标限流 {args.amps:.{psu.i_dec}f} A  →  寄存器 {REG_I_SET} = {raw}"
          f"    (当前 {st['i_set']:.{psu.i_dec}f} A)")
    if args.dry_run:
        print("[dry-run] 未实际写入")
        return 0
    psu._write_verify(REG_I_SET, raw, "电流")

    time.sleep(0.1)
    st2 = psu.status()
    ok = abs(st2["i_set"] - args.amps) <= psu.i_unit / 2
    print(f"回读限流 {st2['i_set']:.{psu.i_dec}f} A   {'✓ 与目标一致' if ok else '✗ 与目标不符'}")
    if not ok:
        raise DeviceError(f"回读 {st2['i_set']} A 与目标 {args.amps} A 不一致")
    return 0


def cmd_set_range(args, psu):
    target = 0 if args.range == "6a" else 1
    st = psu.status()
    if psu.dual_range is False:
        raise SafetyError(f"{psu.model_name} 不支持 6A/12A 档位切换")
    if args.confirm != args.range:
        raise SafetyError(f"两次输入不一致：目标 {args.range}，确认 {args.confirm}。已拒绝执行。")
    if st["i_range"] == target:
        print(f"当前已经是 {args.range} 档，无需操作。")
        return 0
    if target == 0 and st["i_set"] > 6.0:
        raise SafetyError(
            f"当前限流设定 {st['i_set']:.{psu.i_dec}f} A 大于 6A 档上限，切到 6A 档会把限流值强行压到 6A，"
            "可能无声改变你的设定。\n请先把限流改到 6A 以内：python psu.py set-current 6 --confirm 6"
        )
    _guard_output_off(psu, args, "切换电流档位")
    psu._write_verify(REG_I_RANGE, target, "电流档位")
    st2 = psu.status()
    print(f"✓ 档位已切到 {'6A' if st2['i_range'] == 0 else '12A'} 档，当前设定 {st2['v_set']:.{psu.v_dec}f} V / {st2['i_set']:.{psu.i_dec}f} A")
    return 0


def cmd_boot_power(args, psu):
    """开机自动输出（面板 System Setting → Boot Power，寄存器 68）。

    这是实现「远程开关机」的关键一环：串口本身无法控制设备供电，
    但把供电交给 AC 侧智能插座/继电器后，打开 Boot Power 就能在恢复供电时
    自动把输出拉起来，等价于完整的远程开机。
    """
    cur = psu._read_regs(REG_BOOT_POWER, 1)[0]
    if args.state == "status":
        print(f"开机自动输出 Boot Power：{'● 开（上电即输出）' if cur else '○ 关（上电输出关闭）'}")
        if cur:
            st = psu.status()
            print(f"  恢复供电后会立即按 {st['v_set']:.{psu.v_dec}f} V / 限流 {st['i_set']:.{psu.i_dec}f} A 上电")
        return 0

    target = 1 if args.state == "on" else 0
    if args.confirm != args.state:
        raise SafetyError(f"两次输入不一致：目标 {args.state}，确认 {args.confirm}。已拒绝执行。")
    if cur == target:
        print(f"已经是 {'开启' if cur else '关闭'}状态，无需操作。")
        return 0

    if target == 1:
        st = psu.status()
        print("⚠ 开启后，每次给设备通电都会自动按以下设定输出，无需任何确认：")
        print(f"    {st['v_set']:.{psu.v_dec}f} V / 限流 {st['i_set']:.{psu.i_dec}f} A")
        print("  接有负载时请务必先确认设定值，避免上电瞬间冲击负载。")

    psu._write_verify(REG_BOOT_POWER, target, "开机自动输出")
    now = psu._read_regs(REG_BOOT_POWER, 1)[0]
    print(f"✓ 开机自动输出已{'开启' if now else '关闭'}（回读寄存器 {REG_BOOT_POWER} = {now}）")
    if now != target:
        raise DeviceError("回读与目标不一致")
    if target == 1:
        print("  下次通电将自动输出；该设置掉电保存，重启后依然有效。")
    return 0


def cmd_ping(args):
    """探活：设备是否在线可通信。用于继电器/智能插座上电后等待电源启动。"""
    deadline = time.time() + args.wait
    attempt = 0
    while True:
        attempt += 1
        try:
            with PSU(port=args.port, addr=args.addr, quiet=True) as psu:
                st = psu.status()
            print(f"✓ 设备在线：{st['model']} @{st['port']}  FW {st['firmware']}  "
                  f"输出{'开' if st['output'] else '关'}（第 {attempt} 次探测）")
            return 0
        except DeviceError:
            if time.time() >= deadline:
                sys.stderr.write(f"✗ 等待 {args.wait}s 后设备仍未响应（探测 {attempt} 次）\n")
                return 3
            time.sleep(args.interval)


def cmd_monitor(args, psu):
    print(f"采样 {args.count} 次，间隔 {args.interval}s，Ctrl+C 中断\n")
    print(f"{'时间':<10}{'V设定':>9}{'I设定':>9}{'V实测':>9}{'I实测':>10}{'功率':>9}  {'模式':<3} 输出")
    print("-" * 74)
    try:
        for idx in range(args.count):
            st = psu.status()
            print(
                f"{time.strftime('%H:%M:%S'):<10}"
                f"{st['v_set']:>9.{psu.v_dec}f}{st['i_set']:>9.{psu.i_dec}f}"
                f"{st['v_out']:>9.{psu.v_dec}f}{st['i_out']:>10.{psu.i_dec}f}"
                f"{st['power']:>9.2f}  {st['mode']:<3} {'开' if st['output'] else '关'}"
            )
            if idx < args.count - 1:
                time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n已中断")
    return 0


def cmd_read(args, psu):
    if args.raw:
        names = {
            0: "ID", 1: "SN_HI", 2: "SN_LO", 3: "FW", 4: "T_SIGN", 5: "T_C", 6: "TF_SIGN", 7: "T_F",
            8: "V_SET", 9: "I_SET", 10: "V_OUT", 11: "I_OUT", 12: "PWR_HI", 13: "POWER", 14: "V_IN",
            15: "LOCK", 16: "PROTECT", 17: "CVCC", 18: "OUTPUT", 19: "PRESET", 20: "I_RANGE",
            80: "M0_V", 81: "M0_I", 82: "M0_OVP", 83: "M0_OCP",
        }
        print(f"{'reg':>4}  {'name':<9}{'raw':>7}    换算")
        print("-" * 46)
        for reg in (list(range(0, 21)) + [80, 81, 82, 83]):
            val = psu._read_regs(reg, 1)[0]
            conv = ""
            unit = psu.v_unit if reg in (8, 10, 80, 82) else (psu.i_unit if reg in (9, 11, 81, 83) else None)
            if unit:
                conv = f"{val * unit:.{psu.v_dec if 'V' in names[reg] else psu.i_dec}f}"
            elif reg == 14:
                conv = f"{val / 100:.2f} V"
            elif reg == 3:
                conv = f"v{val / 100:.2f}"
            print(f"{reg:>4}  {names.get(reg, ''):<9}{val:>7}    {conv}")
        return 0
    print(json.dumps({k: v for k, v in psu.status().items() if not k.startswith("_")}, ensure_ascii=False, indent=2))
    return 0


# ---------------------------------------------------------------- 参数解析
def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--port", default="auto", help="串口号，如 COM24；默认 auto 自动搜索")
    common.add_argument("--addr", type=int, default=DEFAULT_ADDR, help="Modbus 从站地址，默认 1")
    common.add_argument("--json", action="store_true", help="以 JSON 输出（仅查询类命令）")

    p = argparse.ArgumentParser(
        description="RIDEN RD60xx 直流电源串口控制（安全优先）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="危险操作都会被 --confirm 二次校验拦住，详见 SKILL.md",
    )
    p.add_argument("--port", default="auto")
    p.add_argument("--addr", type=int, default=DEFAULT_ADDR)
    p.add_argument("--json", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("ports", help="列出本机串口")
    sub.add_parser("status", parents=[common], help="读当前状态（只读）")

    sp = sub.add_parser("ping", parents=[common], help="探活：设备是否在线")
    sp.add_argument("--wait", type=float, default=0, help="最多等待多少秒（用于等待上电启动）")
    sp.add_argument("--interval", type=float, default=1.0, help="重试间隔，默认 1s")

    sp = sub.add_parser("output", parents=[common], help="开/关输出")
    sp.add_argument("state", choices=["on", "off"])
    sp.add_argument("--expect-volts", type=float, default=None, help="打开输出前核对的预期电压（on 时必填）")
    sp.add_argument("--force", action="store_true", help="跳过 --expect-volts 核对（不推荐）")

    sp = sub.add_parser("set-voltage", parents=[common], help="设定电压（需二次确认）")
    sp.add_argument("volts", type=float)
    sp.add_argument("--confirm", type=float, required=True, help="再写一遍目标电压，必须与 volts 一致")
    sp.add_argument("--allow-live", action="store_true", help="允许在输出开启时改（危险）")
    sp.add_argument("--allow-over-ovp", action="store_true", help="允许设定高于 OVP 的电压")
    sp.add_argument("--dry-run", action="store_true")

    sp = sub.add_parser("set-current", parents=[common], help="设定限流（需二次确认）")
    sp.add_argument("amps", type=float)
    sp.add_argument("--confirm", type=float, required=True, help="再写一遍目标电流，必须与 amps 一致")
    sp.add_argument("--allow-live", action="store_true")
    sp.add_argument("--dry-run", action="store_true")

    sp = sub.add_parser("set-range", parents=[common], help="切换 6A/12A 电流档位")
    sp.add_argument("range", choices=["6a", "12a"])
    sp.add_argument("--confirm", required=True, choices=["6a", "12a"], help="再写一遍目标档位")
    sp.add_argument("--allow-live", action="store_true")

    sp = sub.add_parser("boot-power", parents=[common], help="开机自动输出开关（配合 AC 侧继电器实现远程开关机）")
    sp.add_argument("state", choices=["on", "off", "status"])
    sp.add_argument("--confirm", choices=["on", "off"], default=None, help="再写一遍目标状态")

    sp = sub.add_parser("monitor", parents=[common], help="连续采样")
    sp.add_argument("-n", "--count", type=int, default=10)
    sp.add_argument("-i", "--interval", type=float, default=1.0)

    sp = sub.add_parser("read", parents=[common], help="导出全部关键寄存器")
    sp.add_argument("--raw", action="store_true", help="打印原始寄存器值")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.cmd == "ports":
        return cmd_ports(args)
    if args.cmd == "ping":
        return cmd_ping(args)

    handlers = {
        "status": cmd_status,
        "output": cmd_output,
        "set-voltage": cmd_set_voltage,
        "set-current": cmd_set_current,
        "set-range": cmd_set_range,
        "boot-power": cmd_boot_power,
        "monitor": cmd_monitor,
        "read": cmd_read,
    }
    try:
        with PSU(port=args.port, addr=args.addr, quiet=args.json) as psu:
            return handlers[args.cmd](args, psu)
    except SafetyError as exc:
        sys.stderr.write(f"\n✗ 已拒绝执行（安全校验未通过）\n{exc}\n")
        return 2
    except DeviceError as exc:
        sys.stderr.write(f"\n✗ 设备操作失败\n{exc}\n")
        return 3
    except KeyboardInterrupt:
        sys.stderr.write("\n已中断\n")
        return 130


if __name__ == "__main__":
    sys.exit(main())
